from flask import Flask, render_template, request
import pandas as pd

# Load the CSV file into a DataFrame
df = pd.read_csv('Data for repository.csv')

app = Flask(__name__)

# Function to recommend movies based on Genre similarity
def recommend_movies(movie_name, genre):
    if movie_name:
        # Check if the movie exists in the dataset
        movie = df[df['Movie Name'].str.contains(movie_name, case=False)]
        if not movie.empty:
            genre = movie['Genre'].iloc[0]
            # Find movies with the same genre as the given movie
            similar_movies = df.loc[(df['Genre'] == genre) & (df['Movie Name'] != movie_name), 'Movie Name'].tolist()
        else:
            # If the movie doesn't exist, return empty list
            similar_movies = []
    elif genre:
        # Find movies with the same Genre as the selected genre
        similar_movies = df.loc[df['Genre'] == genre, 'Movie Name'].tolist()
    else:
        similar_movies = df['Movie Name'].tolist()
    
    return similar_movies

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/recommend', methods=['POST'])
def recommend():
    movie_name = request.form.get('search_term')
    genre = request.form.get('genre')
    
    # Get recommended movies
    recommended_movies = recommend_movies(movie_name, genre)
    
    # Render recommendations
    return render_template('recommendations.html', movie_name=movie_name, recommended_movies=recommended_movies)

if __name__ == '__main__':
    app.run(debug=True)
